import { LightningElement,api } from 'lwc';

export default class AccountDetails extends LightningElement {
    @api recordId;
}